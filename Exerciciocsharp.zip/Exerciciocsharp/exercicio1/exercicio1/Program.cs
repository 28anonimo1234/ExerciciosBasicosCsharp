﻿using System;

class Program

{
    static void Main()
    {
        Console.Write("Digite a cotação do dólar ");
        double cotacao = double.Parse(Console.ReadLine());


        Console.Write("Digite o valor em dolares");
        double valorDolar = double.Parse(Console.ReadLine());

        double valorReal = valorDolar * cotacao;


        Console.WriteLine($"O  valor em reais é: R$ {valorReal:F2}");

    }
}