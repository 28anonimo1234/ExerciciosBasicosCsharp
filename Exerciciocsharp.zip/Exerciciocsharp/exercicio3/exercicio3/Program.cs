﻿using System;

class Program
{
    static void Main()
    {
        // Teste
        Console.Write("Digite a quantidade mínima da peça: ");
        int quantidadeMinima = int.Parse(Console.ReadLine());

        
        Console.Write("Digite a quantidade máxima da peça: ");
        int quantidadeMaxima = int.Parse(Console.ReadLine());

        
        double estoqueMedio = (quantidadeMinima + quantidadeMaxima) / 2.0;

        
        Console.WriteLine($"O estoque médio da peça é: {estoqueMedio}");
    }
}
