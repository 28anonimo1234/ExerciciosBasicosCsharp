﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite um número inteiro: ");
        int numero = int.Parse(Console.ReadLine());

        int modulo;

        
        if (numero >= 0)
        {
            modulo = numero; 
        }
        else
        {
            modulo = numero * -1; 
        }

        
        Console.WriteLine($"O módulo do número {numero} é: {modulo}");
    }
}
