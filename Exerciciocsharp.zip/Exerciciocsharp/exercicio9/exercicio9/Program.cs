﻿using System;

class Program
{
    static void Main()
    {
        for (int i = 100; i >= 1; i--)
        {
            Console.WriteLine(i);
        }
    }
}
