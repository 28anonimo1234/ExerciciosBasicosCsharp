﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite o primeiro número: ");
        int num1 = int.Parse(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        int num2 = int.Parse(Console.ReadLine());

        Console.Write("Digite o terceiro número: ");
        int num3 = int.Parse(Console.ReadLine());

        
        int[] numeros = { num1, num2, num3 };

        
        Array.Sort(numeros);
        Array.Reverse(numeros);

        
        Console.WriteLine("Números em ordem decrescente:");
        foreach (int num in numeros)
        {
            Console.WriteLine(num);
        }
    }
}
