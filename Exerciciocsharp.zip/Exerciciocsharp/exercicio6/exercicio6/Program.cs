﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite o primeiro número: ");
        int num1 = int.Parse(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        int num2 = int.Parse(Console.ReadLine());

        int maior, menor;

        
        if (num1 > num2)
        {
            maior = num1;
            menor = num2;
        }
        else
        {
            maior = num2;
            menor = num1;
        }


        int diferenca = maior - menor;

        
        Console.WriteLine($"A diferença do maior para o menor é: {diferenca}");
    }
}

// não consegui testar no pc