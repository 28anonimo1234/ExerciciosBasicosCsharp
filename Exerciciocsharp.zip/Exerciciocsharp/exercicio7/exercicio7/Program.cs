﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite o primeiro número: ");
        int num1 = int.Parse(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        int num2 = int.Parse(Console.ReadLine());

        
        if (num1 == num2)
        {
            Console.WriteLine("Os dois números são iguais.");
        }
        else if (num1 > num2)
        {
            Console.WriteLine($"O maior número é: {num1}");
            Console.WriteLine($"O menor número é: {num2}");
        }
        else
        {
            Console.WriteLine($"O maior número é: {num2}");
            Console.WriteLine($"O menor número é: {num1}");
        }
    }
}
