﻿
using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite a identificação do vendedor: ");
        string vendedor = Console.ReadLine();

        
        Console.Write("Digite o código da peça: ");
        string codigoPeca = Console.ReadLine();

        
        Console.Write("Digite o preço unitário da peça: ");
        double precoUnitario = double.Parse(Console.ReadLine());

        
        Console.Write("Digite a quantidade vendida: ");
        int quantidade = int.Parse(Console.ReadLine());

        
        double totalVenda = precoUnitario * quantidade;

        
        double comissao = totalVenda * 0.05;

        
        Console.WriteLine();
        Console.WriteLine($"Vendedor: {vendedor}");
        Console.WriteLine($"Código da peça: {codigoPeca}");
        Console.WriteLine($"Total da venda: R$ {totalVenda:F2}");
        Console.WriteLine($"Comissão (5%): R$ {comissao:F2}");
    }
}
